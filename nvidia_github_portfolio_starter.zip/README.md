# Hardware & GPU Computing Portfolio

A starter portfolio for digital design, RTL verification, and GPU-computing exploration.

## Projects

1. **Synchronous FIFO RTL** — parameterized Verilog FIFO with full/empty flags and a self-checking testbench.
2. **APB Register Peripheral** — simple APB-style register block with a testbench for writes and reads.
3. **CPU vs GPU Array Benchmark** — Python benchmark comparing NumPy CPU computation with optional CuPy GPU computation.

## Important
These are starter implementations. Run the simulations and benchmark in your own environment before describing results as verified. Do not claim hardware implementation, FPGA deployment, or GPU speedups unless you actually completed them.

## Tools
- Verilog/SystemVerilog simulator: Icarus Verilog or Questa/ModelSim
- Python 3
- NumPy; optional CuPy and a compatible NVIDIA GPU/CUDA environment

## Suggested profile tagline
Electrical/Electronics Engineering | RTL Design | Digital Design | Verification | Python

## Repositories
Each project directory has its own README with usage instructions.
