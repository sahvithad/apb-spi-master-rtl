# CPU vs GPU Array Benchmark

A small Python exercise for comparing array computation on CPU (NumPy) and GPU (CuPy, if installed and configured).

## Install
```bash
python -m pip install numpy
```

Optional GPU path:
```bash
python -m pip install cupy-cuda12x
```
Choose the CuPy package matching your installed CUDA environment; the example above is not appropriate for every setup.

## Run
```bash
python benchmark.py
```

The script reports elapsed times and checks numerical agreement. It does not guarantee GPU acceleration: results depend on GPU, CUDA setup, array size, warm-up, and transfer overhead. Record your actual output in the README only after running it on your system.
