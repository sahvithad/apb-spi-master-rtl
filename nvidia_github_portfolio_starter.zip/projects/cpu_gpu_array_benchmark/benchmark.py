import time
import numpy as np

SIZE = 2_000_000
REPEATS = 5

def run_cpu(a, b):
    start = time.perf_counter()
    result = None
    for _ in range(REPEATS):
        result = np.sin(a) * np.cos(b) + a * 0.25
    return result, time.perf_counter() - start

def main():
    rng = np.random.default_rng(7)
    a = rng.random(SIZE, dtype=np.float32)
    b = rng.random(SIZE, dtype=np.float32)

    cpu_result, cpu_time = run_cpu(a, b)
    print(f"CPU NumPy: {cpu_time:.6f} s total for {REPEATS} runs")

    try:
        import cupy as cp
        ga = cp.asarray(a)
        gb = cp.asarray(b)
        cp.cuda.Stream.null.synchronize()
        start = time.perf_counter()
        gpu_result = None
        for _ in range(REPEATS):
            gpu_result = cp.sin(ga) * cp.cos(gb) + ga * 0.25
        cp.cuda.Stream.null.synchronize()
        gpu_time = time.perf_counter() - start
        gpu_result = cp.asnumpy(gpu_result)
        print(f"GPU CuPy: {gpu_time:.6f} s total for {REPEATS} runs")
        print(f"Max absolute difference: {np.max(np.abs(cpu_result - gpu_result)):.8g}")
        if gpu_time > 0:
            print(f"Measured speedup (kernel + synchronization, excluding initial transfer): {cpu_time / gpu_time:.3f}x")
    except ImportError:
        print("CuPy not installed; GPU benchmark skipped.")
    except Exception as exc:
        print(f"GPU path unavailable: {exc}")

if __name__ == "__main__":
    main()
