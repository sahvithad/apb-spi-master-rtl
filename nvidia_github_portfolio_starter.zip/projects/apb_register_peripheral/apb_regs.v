module apb_regs (
    input wire pclk,
    input wire presetn,
    input wire psel,
    input wire penable,
    input wire pwrite,
    input wire [3:0] paddr,
    input wire [31:0] pwdata,
    output reg [31:0] prdata,
    output wire pready,
    output wire pslverr
);
    reg [31:0] reg0;
    reg [31:0] reg1;

    assign pready = 1'b1;
    assign pslverr = 1'b0;

    always @(posedge pclk or negedge presetn) begin
        if (!presetn) begin
            reg0 <= 0;
            reg1 <= 0;
        end else if (psel && penable && pwrite) begin
            case (paddr)
                4'h0: reg0 <= pwdata;
                4'h4: reg1 <= pwdata;
                default: begin end
            endcase
        end
    end

    always @* begin
        prdata = 32'b0;
        if (psel && !pwrite) begin
            case (paddr)
                4'h0: prdata = reg0;
                4'h4: prdata = reg1;
                default: prdata = 32'b0;
            endcase
        end
    end
endmodule
