# APB-Style Register Peripheral

A compact memory-mapped register block illustrating an APB-like setup/access transfer.

## Files
- `apb_regs.v` — register peripheral
- `tb_apb_regs.v` — testbench that writes and reads a register

## Run
```bash
iverilog -g2012 -o apb_sim apb_regs.v tb_apb_regs.v
vvp apb_sim
```

## Interface behavior
- A transfer is selected when `psel && penable && pwrite` is high.
- Reads return the selected register while selected.
- This is an educational APB-style example, not a complete AMBA compliance implementation.
