`timescale 1ns/1ps
module tb_apb_regs;
    reg pclk = 0;
    reg presetn = 0;
    reg psel = 0;
    reg penable = 0;
    reg pwrite = 0;
    reg [3:0] paddr = 0;
    reg [31:0] pwdata = 0;
    wire [31:0] prdata;
    wire pready, pslverr;

    apb_regs dut (
        .pclk(pclk), .presetn(presetn), .psel(psel), .penable(penable),
        .pwrite(pwrite), .paddr(paddr), .pwdata(pwdata),
        .prdata(prdata), .pready(pready), .pslverr(pslverr)
    );

    always #5 pclk = ~pclk;

    initial begin
        repeat (2) @(negedge pclk);
        presetn = 1;

        psel = 1; penable = 1; pwrite = 1;
        paddr = 0; pwdata = 32'h1234ABCD;
        @(negedge pclk);
        psel = 0; penable = 0; pwrite = 0;

        psel = 1; paddr = 0;
        #1;
        if (prdata !== 32'h1234ABCD) $fatal(1, "Readback mismatch: %h", prdata);
        if (!pready || pslverr) $fatal(1, "Unexpected APB status");
        $display("PASS: APB-style register write/read test");
        $finish;
    end
endmodule
